from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser


@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'mobile', 'ward', 'is_blocked', 'is_verified')
    list_filter = ('role', 'is_blocked', 'is_verified', 'ward')
    search_fields = ('username', 'email', 'first_name', 'last_name', 'mobile', 'aadhaar')
    ordering = ('-date_joined',)

    fieldsets = UserAdmin.fieldsets + (
        ('Role & Status', {'fields': ('role', 'is_verified', 'is_blocked')}),
        ('Contact Info', {'fields': ('mobile', 'aadhaar', 'ward', 'block', 'address')}),
        ('Notifications', {'fields': ('sms_notifications', 'email_notifications', 'city_announcements', 'feedback_reminders')}),
    )
