from django.contrib.auth.models import AbstractUser
from django.db import models


class CustomUser(AbstractUser):
    ROLE_CHOICES = (
        ('admin', 'Admin'),
        ('department', 'Department Officer'),
        ('citizen', 'Citizen'),
    )

    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='citizen')
    mobile = models.CharField(max_length=15, blank=True)
    aadhaar = models.CharField(max_length=14, blank=True)
    ward = models.CharField(max_length=50, blank=True)
    block = models.CharField(max_length=50, blank=True)
    address = models.TextField(blank=True)
    is_verified = models.BooleanField(default=False)
    is_blocked = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    # Notification preferences
    sms_notifications = models.BooleanField(default=True)
    email_notifications = models.BooleanField(default=True)
    city_announcements = models.BooleanField(default=True)
    feedback_reminders = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.get_full_name() or self.username} ({self.role})"

    @property
    def is_admin(self):
        return self.role == 'admin'

    @property
    def is_department(self):
        return self.role == 'department'

    @property
    def is_citizen(self):
        return self.role == 'citizen'

    def get_initials(self):
        if self.first_name and self.last_name:
            return f"{self.first_name[0]}{self.last_name[0]}".upper()
        return self.username[:2].upper()
