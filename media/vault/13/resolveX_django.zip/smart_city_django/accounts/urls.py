from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('login/', views.general_login_view, name='general_login'),
    path('citizen/login/', views.citizen_login_view, name='citizen_login'),
    path('dept/login/', views.dept_login_view, name='dept_login'),
    path('logout/', views.logout_view, name='logout'),
    path('profile/', views.citizen_profile_view, name='citizen_profile'),
    path('admin/users/', views.admin_user_management, name='admin_user_management'),
    path('admin/users/toggle/<int:user_id>/', views.admin_toggle_user, name='admin_toggle_user'),
]
