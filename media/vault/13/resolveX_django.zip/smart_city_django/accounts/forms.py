from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import CustomUser


class CitizenRegistrationForm(UserCreationForm):
    first_name = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={'placeholder': 'Rahul', 'class': 'form-control-sc'}))
    last_name = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={'placeholder': 'Kumar', 'class': 'form-control-sc'}))
    mobile = forms.CharField(max_length=15, required=True, widget=forms.TextInput(attrs={'placeholder': '+91 98765 43210', 'class': 'form-control-sc'}))
    email = forms.EmailField(required=True, widget=forms.EmailInput(attrs={'placeholder': 'you@email.com', 'class': 'form-control-sc'}))
    aadhaar = forms.CharField(max_length=14, required=True, widget=forms.TextInput(attrs={'placeholder': 'XXXX-XXXX-XXXX', 'class': 'form-control-sc'}))
    address = forms.CharField(required=True, widget=forms.Textarea(attrs={'placeholder': 'Enter your address', 'class': 'form-control', 'rows': 3}))
    ward = forms.ChoiceField(choices=[('', 'Select Ward')] + [(f'Ward {i}', f'Ward {i}') for i in range(1, 21)], widget=forms.Select(attrs={'class': 'form-control-sc'}))
    block = forms.CharField(max_length=50, required=True, widget=forms.TextInput(attrs={'placeholder': 'Block B', 'class': 'form-control-sc'}))
    password1 = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Min 8 characters', 'class': 'form-control-sc'}))
    password2 = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': 'Confirm password', 'class': 'form-control-sc'}))

    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name', 'mobile', 'email', 'aadhaar', 'address', 'ward', 'block', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.username = self.cleaned_data['email']
        user.role = 'citizen'
        if commit:
            user.save()
        return user


class CitizenLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': '+91 98765 43210 or Email', 'class': 'form-control-sc'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': '••••••••', 'class': 'form-control-sc'}))


class DepartmentLoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'placeholder': 'dept.officer@smartcity.gov.in', 'class': 'form-input-sc'}))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder': '••••••••', 'class': 'form-input-sc'}))


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ('first_name', 'last_name', 'mobile', 'email', 'ward', 'block', 'address',
                  'sms_notifications', 'email_notifications', 'city_announcements', 'feedback_reminders')
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-input-sc'}),
            'last_name': forms.TextInput(attrs={'class': 'form-input-sc'}),
            'mobile': forms.TextInput(attrs={'class': 'form-input-sc'}),
            'email': forms.EmailInput(attrs={'class': 'form-input-sc'}),
            'ward': forms.TextInput(attrs={'class': 'form-input-sc'}),
            'block': forms.TextInput(attrs={'class': 'form-input-sc'}),
            'address': forms.Textarea(attrs={'class': 'form-input-sc', 'rows': 3}),
        }
