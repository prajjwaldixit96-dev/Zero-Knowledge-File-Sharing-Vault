from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from .forms import CitizenRegistrationForm, CitizenLoginForm, DepartmentLoginForm, ProfileUpdateForm
from .models import CustomUser
from complaints.models import Complaint
from notifications.models import Notification


def register_view(request):
    form = CitizenRegistrationForm()
    if request.method == 'POST':
        form = CitizenRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            messages.success(request, 'Account created successfully! Please log in.')
            return redirect('citizen_login')
        else:
            messages.error(request, 'Please fix the errors below.')
    return render(request, 'general/register.html', {'form': form})


def general_login_view(request):
    """Unified login that redirects based on role"""
    if request.user.is_authenticated:
        return redirect_by_role(request.user)
    
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user:
            if user.is_blocked:
                messages.error(request, 'Your account has been blocked. Contact admin.')
                return redirect('general_login')
            login(request, user)
            return redirect_by_role(user)
        else:
            messages.error(request, 'Invalid credentials. Please try again.')
    return render(request, 'general/login.html')


def redirect_by_role(user):
    from django.shortcuts import redirect
    if user.role == 'admin' or user.is_superuser:
        return redirect('admin_dashboard')
    elif user.role == 'department':
        return redirect('dept_dashboard')
    else:
        return redirect('citizen_dashboard')


def citizen_login_view(request):
    if request.user.is_authenticated and request.user.role == 'citizen':
        return redirect('citizen_dashboard')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user and user.role == 'citizen':
            if user.is_blocked:
                messages.error(request, 'Your account has been blocked.')
                return redirect('citizen_login')
            login(request, user)
            return redirect('citizen_dashboard')
        else:
            messages.error(request, 'Invalid credentials.')
    return render(request, 'citizen_zone/login.html')


def dept_login_view(request):
    if request.user.is_authenticated and request.user.role == 'department':
        return redirect('dept_dashboard')
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user and user.role == 'department':
            login(request, user)
            return redirect('dept_dashboard')
        else:
            messages.error(request, 'Invalid department credentials.')
    return render(request, 'dept_zone/login.html')


def logout_view(request):
    logout(request)
    return redirect('home')


@login_required
def citizen_profile_view(request):
    if request.user.role != 'citizen':
        return redirect('home')

    password_form = PasswordChangeForm(request.user)

    if request.method == 'POST':
        action = request.POST.get('action')
        if action == 'update_profile':
            form = ProfileUpdateForm(request.POST, instance=request.user)
            if form.is_valid():
                form.save()
                messages.success(request, 'Profile updated successfully!')
                return redirect('citizen_profile')
        elif action == 'change_password':
            password_form = PasswordChangeForm(request.user, request.POST)
            if password_form.is_valid():
                user = password_form.save()
                update_session_auth_hash(request, user)
                messages.success(request, 'Password changed successfully!')
                return redirect('citizen_profile')

    form = ProfileUpdateForm(instance=request.user)
    notifications = Notification.objects.filter(user=request.user, is_read=False).count()
    return render(request, 'citizen_zone/profile.html', {
        'form': form,
        'password_form': password_form,
        'unread_notifications': notifications,
    })


# ─── Admin: User Management ─────────────────────────────────────────────────

def admin_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or (request.user.role != 'admin' and not request.user.is_superuser):
            return redirect('general_login')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@admin_required
def admin_user_management(request):
    citizens = CustomUser.objects.filter(role='citizen').order_by('-created_at')
    return render(request, 'admin_zone/users.html', {'citizens': citizens})


@login_required
@admin_required
def admin_toggle_user(request, user_id):
    if request.method == 'POST':
        user = get_object_or_404(CustomUser, id=user_id)
        user.is_blocked = not user.is_blocked
        user.save()
        action = 'blocked' if user.is_blocked else 'unblocked'
        messages.success(request, f'User {user.get_full_name()} has been {action}.')
    return redirect('admin_user_management')
