"""
Management command to seed initial data for ResolveX.
Run with: python manage.py seed_data
"""
from django.core.management.base import BaseCommand
from django.contrib.auth import get_user_model
from departments.models import Department
from complaints.models import ComplaintCategory, SubCategory

User = get_user_model()


class Command(BaseCommand):
    help = 'Seeds the database with initial data (admin, departments, categories)'

    def handle(self, *args, **options):
        self.stdout.write(self.style.MIGRATE_HEADING('=== ResolveX — Seed Data ==='))

        # ── 1. SUPERUSER / ADMIN ─────────────────────────────────────────────
        if not User.objects.filter(username='admin@smartcity.gov.in').exists():
            admin = User.objects.create_superuser(
                username='admin@smartcity.gov.in',
                email='admin@smartcity.gov.in',
                password='Admin@1234',
                first_name='Super',
                last_name='Admin',
                role='admin',
            )
            self.stdout.write(self.style.SUCCESS(f'✓ Admin user created → admin@smartcity.gov.in / Admin@1234'))
        else:
            admin = User.objects.get(username='admin@smartcity.gov.in')
            self.stdout.write(f'  Admin user already exists.')

        # ── 2. DEPARTMENTS + OFFICERS ────────────────────────────────────────
        departments_data = [
            {'name': 'Water Supply', 'head_name': 'R. Sharma', 'sla_hours': 72, 'username': 'water@dept.gov.in'},
            {'name': 'Roads & Infrastructure', 'head_name': 'M. Patel', 'sla_hours': 168, 'username': 'roads@dept.gov.in'},
            {'name': 'Sanitation', 'head_name': 'K. Singh', 'sla_hours': 120, 'username': 'sanitation@dept.gov.in'},
            {'name': 'Electricity Board', 'head_name': 'P. Gupta', 'sla_hours': 24, 'username': 'electricity@dept.gov.in'},
            {'name': 'Street Lights', 'head_name': 'A. Verma', 'sla_hours': 48, 'username': 'streetlights@dept.gov.in'},
            {'name': 'Parks & Horticulture', 'head_name': 'S. Rao', 'sla_hours': 120, 'username': 'parks@dept.gov.in'},
        ]

        for d_data in departments_data:
            username = d_data.pop('username')
            # Create officer user
            if not User.objects.filter(username=username).exists():
                officer = User.objects.create_user(
                    username=username,
                    email=username,
                    password='Dept@1234',
                    first_name=d_data['name'].split()[0],
                    last_name='Officer',
                    role='department',
                    is_verified=True,
                )
                self.stdout.write(self.style.SUCCESS(f'  ✓ Officer created → {username} / Dept@1234'))
            else:
                officer = User.objects.get(username=username)

            dept, created = Department.objects.get_or_create(
                name=d_data['name'],
                defaults={**d_data, 'officer': officer, 'is_active': True}
            )
            if created:
                self.stdout.write(self.style.SUCCESS(f'  ✓ Department created: {dept.name}'))
            else:
                self.stdout.write(f'  Department already exists: {dept.name}')

        # ── 3. COMPLAINT CATEGORIES & SUBCATEGORIES ──────────────────────────
        categories_data = {
            'Water Supply': ['No Water Supply', 'Pipe Leakage', 'Low Pressure', 'Water Contamination', 'Damaged Water Meter'],
            'Roads & Infrastructure': ['Pothole', 'Road Damage', 'Footpath Damage', 'Broken Divider', 'Waterlogging'],
            'Sanitation': ['Garbage Pile-up', 'Blocked Drain', 'Overflowing Dustbin', 'Stray Animals', 'Public Toilet Issue'],
            'Electricity': ['Power Cut', 'Meter Issue', 'Transformer Fault', 'Illegal Connection', 'High Bill Complaint'],
            'Street Lights': ['Street Light Not Working', 'Damaged Pole', 'Wiring Hazard', 'Light On During Day'],
            'Parks & Public Spaces': ['Park Maintenance', 'Tree Fallen', 'Encroachment', 'Noise Pollution'],
            'Other': ['Other Civic Issue', 'General Complaint'],
        }

        for cat_name, subcats in categories_data.items():
            cat, created = ComplaintCategory.objects.get_or_create(name=cat_name, defaults={'is_active': True})
            if created:
                self.stdout.write(self.style.SUCCESS(f'  ✓ Category created: {cat_name}'))
            for sub in subcats:
                SubCategory.objects.get_or_create(category=cat, name=sub, defaults={'is_active': True})

        # ── 4. DEMO CITIZEN ──────────────────────────────────────────────────
        if not User.objects.filter(username='rahul@citizen.com').exists():
            citizen = User.objects.create_user(
                username='rahul@citizen.com',
                email='rahul@citizen.com',
                password='Citizen@1234',
                first_name='Rahul',
                last_name='Kumar',
                role='citizen',
                mobile='+91 98765 43210',
                ward='Ward 7',
                block='Block B',
                address='Ward 7, Block B, Near Water Tank',
                is_verified=True,
            )
            self.stdout.write(self.style.SUCCESS(f'✓ Demo citizen created → rahul@citizen.com / Citizen@1234'))

        self.stdout.write('')
        self.stdout.write(self.style.SUCCESS('=== Seed data complete! ==='))
        self.stdout.write('')
        self.stdout.write(self.style.WARNING('LOGIN CREDENTIALS:'))
        self.stdout.write('  Admin     → admin@smartcity.gov.in  / Admin@1234')
        self.stdout.write('  Dept      → water@dept.gov.in       / Dept@1234')
        self.stdout.write('  Citizen   → rahul@citizen.com       / Citizen@1234')
        self.stdout.write('')
        self.stdout.write(self.style.WARNING('Next: python manage.py runserver'))
