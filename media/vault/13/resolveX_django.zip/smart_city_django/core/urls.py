from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('guidelines/', views.guidelines, name='guidelines'),
    path('notices/', views.notices, name='notices'),
    path('contact/', views.contact, name='contact'),
    path('faq/', views.faq, name='faq'),
]
