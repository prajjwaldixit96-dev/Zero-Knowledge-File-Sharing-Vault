from django.shortcuts import render, redirect
from django.contrib import messages
from notifications.models import Announcement
from complaints.models import Complaint
from accounts.models import CustomUser
from departments.models import Department


def home(request):
    total_citizens = CustomUser.objects.filter(role='citizen').count()
    total_complaints = Complaint.objects.count()
    resolved = Complaint.objects.filter(status='resolved').count()
    recent_announcements = Announcement.objects.filter(is_active=True).order_by('-created_at')[:3]
    return render(request, 'general/home.html', {
        'total_citizens': total_citizens,
        'total_complaints': total_complaints,
        'resolved': resolved,
        'recent_announcements': recent_announcements,
    })


def about(request):
    return render(request, 'general/about.html')


def guidelines(request):
    return render(request, 'general/guidelines.html')


def notices(request):
    announcements = Announcement.objects.filter(is_active=True).order_by('-created_at')
    return render(request, 'general/notices.html', {'announcements': announcements})


def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        contact_info = request.POST.get('contact', '').strip()
        subject = request.POST.get('subject', '').strip()
        message = request.POST.get('message', '').strip()
        if name and message:
            messages.success(request, 'Your message has been sent! We will get back to you soon.')
        else:
            messages.error(request, 'Please fill in all required fields.')
        return redirect('contact')
    return render(request, 'general/contact.html')


def faq(request):
    return render(request, 'general/faq.html')
