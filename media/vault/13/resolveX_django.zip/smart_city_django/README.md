# ResolveX: Complaint and Grievance Redressal System
### Django Backend — Complete Setup Guide

---

## 📁 Project Structure

```
smart_city_django/
├── manage.py
├── requirements.txt
├── db.sqlite3                  ← auto-created after migrations
├── smart_city_project/
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── accounts/                   ← Custom User, login, registration
├── complaints/                 ← Core complaint logic (citizen + admin + dept)
├── departments/                ← Department CRUD
├── notifications/              ← Notifications & Announcements
├── core/                       ← Public pages (home, about, contact…)
├── templates/
│   ├── base_app.html           ← Base for sidebar-layout pages
│   ├── base_general.html       ← Base for public pages
│   ├── admin_zone/             ← Admin templates
│   ├── citizen_zone/           ← Citizen templates
│   ├── dept_zone/              ← Department templates
│   └── general/                ← Public-facing templates
├── static/
│   ├── css/
│   │   ├── sc-bs5.css          ← Original app CSS
│   │   └── general.css         ← Public pages CSS
│   └── js/
│       └── sc-app.js           ← Original JS
└── media/                      ← Uploaded complaint photos
```

---

## ⚡ Quick Start (PyCharm)

### Step 1 — Open Project in PyCharm
- File → Open → select the `smart_city_django` folder

### Step 2 — Create Virtual Environment
In PyCharm Terminal:
```bash
python -m venv venv
```

### Step 3 — Activate Virtual Environment
**Windows:**
```bash
venv\Scripts\activate
```
**Mac/Linux:**
```bash
source venv/bin/activate
```

### Step 4 — Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 5 — Run Migrations
```bash
python manage.py makemigrations accounts
python manage.py makemigrations complaints
python manage.py makemigrations departments
python manage.py makemigrations notifications
python manage.py makemigrations core
python manage.py migrate
```

### Step 6 — Seed Initial Data (IMPORTANT!)
This creates the admin, department officers, categories, and a demo citizen:
```bash
python manage.py seed_data
```

### Step 7 — Run the Server
```bash
python manage.py runserver
```

### Step 8 — Open Browser
Visit: **http://127.0.0.1:8000/**

---

## 🔐 Login Credentials (after seed_data)

| Role        | Username                     | Password       | Dashboard URL              |
|-------------|------------------------------|----------------|----------------------------|
| Admin       | admin@smartcity.gov.in       | Admin@1234     | /complaints/admin/dashboard/ |
| Department  | water@dept.gov.in            | Dept@1234      | /complaints/dept/dashboard/  |
| Citizen     | rahul@citizen.com            | Citizen@1234   | /complaints/dashboard/       |

Other department logins (all password: `Dept@1234`):
- `roads@dept.gov.in`
- `sanitation@dept.gov.in`
- `electricity@dept.gov.in`
- `streetlights@dept.gov.in`

Django Admin Panel: **http://127.0.0.1:8000/admin/**
(login with admin@smartcity.gov.in / Admin@1234)

---

## 🗺️ URL Map

### General / Public
| URL | Page |
|-----|------|
| `/` | Home |
| `/about/` | About |
| `/guidelines/` | How to File |
| `/notices/` | Public Notices |
| `/contact/` | Contact |
| `/faq/` | FAQ |

### Authentication
| URL | Page |
|-----|------|
| `/accounts/register/` | Citizen Registration |
| `/accounts/login/` | General Login |
| `/accounts/citizen/login/` | Citizen Login |
| `/accounts/dept/login/` | Department Login |
| `/accounts/logout/` | Logout |
| `/accounts/profile/` | Citizen Profile |

### Citizen Zone
| URL | Page |
|-----|------|
| `/complaints/dashboard/` | Citizen Dashboard |
| `/complaints/file/` | File Complaint |
| `/complaints/history/` | Complaint History |
| `/complaints/track/<pk>/` | Track Complaint |
| `/complaints/notifications/` | Notifications |
| `/complaints/feedback/` | Feedback |

### Admin Zone
| URL | Page |
|-----|------|
| `/complaints/admin/dashboard/` | Admin Dashboard |
| `/complaints/admin/all/` | Complaint Monitoring |
| `/complaints/admin/assign/` | Complaint Assignment |
| `/accounts/admin/users/` | User Management |
| `/departments/admin/departments/` | Department Management |
| `/notifications/admin/notifications/` | Notifications & Alerts |

### Department Zone
| URL | Page |
|-----|------|
| `/complaints/dept/dashboard/` | Dept Dashboard |
| `/complaints/dept/complaints/` | Assigned Complaints |
| `/complaints/dept/resolve/<pk>/` | Resolve Complaint |
| `/complaints/dept/comms/` | Communications |

---

## 🎭 User Roles & Permissions

| Feature | Admin | Department | Citizen |
|---------|-------|-----------|---------|
| View all complaints | ✅ | ✅ (own dept only) | ✅ (own only) |
| Assign complaints | ✅ | ❌ | ❌ |
| Update complaint status | ✅ | ✅ | ❌ |
| File complaint | ❌ | ❌ | ✅ |
| View dashboard stats | ✅ | ✅ | ✅ |
| Manage departments | ✅ | ❌ | ❌ |
| Manage users | ✅ | ❌ | ❌ |
| Send announcements | ✅ | ❌ | ❌ |
| Submit feedback | ❌ | ❌ | ✅ |
| Message on complaints | ✅ | ✅ | ✅ |

---

## 🗄️ Database Models

### accounts.CustomUser (extends AbstractUser)
- `role` — admin / department / citizen
- `mobile`, `aadhaar`, `ward`, `block`, `address`
- `is_verified`, `is_blocked`
- Notification preferences (sms, email, etc.)

### complaints.Complaint
- `complaint_number` — auto-generated (#3001, #3002…)
- `citizen` → CustomUser
- `category` → ComplaintCategory
- `sub_category` → SubCategory
- `department` → Department (assigned by admin)
- `status` — pending / assigned / in_progress / resolved / rejected / closed
- `priority` — low / medium / high / urgent
- `ward`, `block`, `address`, `latitude`, `longitude`
- `resolution_notes`, `resolved_at`, `resolved_by`

### complaints.ComplaintPhoto
- Uploaded photos linked to a complaint

### complaints.ComplaintTimeline
- Audit trail of every status change

### complaints.Feedback
- 1-5 star rating + quality + comments (after resolution)

### complaints.Message
- Chat messages between citizen ↔ department

### departments.Department
- `name`, `head_name`, `officer` → CustomUser (role=department)
- `sla_hours`, `is_active`

### notifications.Notification
- Per-user notifications linked to complaints

### notifications.Announcement
- Broadcast messages (admin → citizens/depts)

---

## 🔧 Common Issues & Fixes

**Problem:** `no such table` error  
**Fix:** Run `python manage.py migrate`

**Problem:** Images not loading  
**Fix:** Check `MEDIA_URL` in settings.py and ensure Pillow is installed

**Problem:** Static files not loading  
**Fix:** Run `python manage.py collectstatic` (for production only, not needed in DEBUG=True)

**Problem:** Login redirects to wrong page  
**Fix:** Ensure `role` field is set correctly on the user. Use Django admin to verify.

**Problem:** Department officer has no department  
**Fix:** In Django Admin → Departments → assign the officer to the department

---

## 📦 Adding to PyCharm Interpreter

1. Settings → Project → Python Interpreter
2. Click ⚙ → Add Interpreter → Virtualenv
3. Select existing → point to `venv/Scripts/python.exe` (Windows) or `venv/bin/python` (Mac/Linux)

---

## 🚀 Production Notes (Optional)
- Change `DEBUG = False` in settings.py
- Set `SECRET_KEY` to a secure random string
- Switch SQLite to MySQL: update `DATABASES` in settings.py
- Run `python manage.py collectstatic`
- Use Gunicorn + Nginx for deployment
