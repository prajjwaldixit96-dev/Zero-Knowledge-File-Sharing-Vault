/* ── PANEL SWITCHING ── */
function showPanel(panelId) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  const t = document.getElementById(panelId);
  if (t) t.classList.add('active');
}
function navTo(el, panelId) {
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  el.classList.add('active');
  showPanel(panelId);
  const lbl = el.querySelector('.nav-label');
  const h = document.getElementById('hdr-title');
  if (h && lbl) h.textContent = lbl.textContent;
}

/* ── PUBLIC PAGE SWITCHING ── */
function pubPage(name) {
  document.querySelectorAll('.pub-page').forEach(p => {p.style.display='none';p.classList.remove('active');});
  const t = document.getElementById('pg-'+name);
  if (t) {t.style.display='block';t.classList.add('active');}
  document.querySelectorAll('.pub-nav-link').forEach(el=>{
    el.classList.toggle('pub-active', el.dataset.page===name);
  });
  const sc = document.querySelector('.pub-scroll');
  if (sc) sc.scrollTop = 0;
}

/* ── NOTIFICATIONS ── */
function toggleNotif(id) {
  const p = document.getElementById(id);
  if (p) p.classList.toggle('show');
}
document.addEventListener('click', e => {
  document.querySelectorAll('.notif-panel.show').forEach(p => {
    if (!e.target.closest('.hdr-icon-btn') && !e.target.closest('.notif-panel')) p.classList.remove('show');
  });
});

/* ── LOGIN / SHOW DASHBOARD ── */
function loginAndShow(dashId) {
  document.getElementById('pub-zone')?.setAttribute('style','display:none');
  document.getElementById('dash-zone')?.removeAttribute('style');
  showPanel(dashId);
}
function logout() {
  document.getElementById('dash-zone')?.setAttribute('style','display:none');
  document.getElementById('pub-zone')?.removeAttribute('style');
  pubPage('login');
}

/* ── STARS ── */
function setStars(id, n) {
  const row = document.getElementById('stars-'+id);
  if (!row) return;
  row.querySelectorAll('.star').forEach((s,i)=>s.classList.toggle('on',i<n));
  const lbl = document.getElementById('star-lbl-'+id);
  const labels = ['','Poor','Below Average','Good','Very Good','Excellent'];
  if (lbl) lbl.textContent = `${n}/5 — ${labels[n]}`;
}

/* ── CATEGORY PICK ── */
function pickCat(el) {
  el.closest('.cat-grid').querySelectorAll('.cat-card').forEach(c=>c.classList.remove('picked'));
  el.classList.add('picked');
}

/* ── TOGGLE FAQ ── */
function toggleFaq(el) {
  const wasOpen = el.classList.contains('open');
  document.querySelectorAll('.faq-item').forEach(f=>f.classList.remove('open'));
  if (!wasOpen) el.classList.add('open');
}
