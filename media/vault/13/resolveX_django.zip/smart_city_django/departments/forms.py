from django import forms
from .models import Department
from accounts.models import CustomUser


class DepartmentForm(forms.ModelForm):
    class Meta:
        model = Department
        fields = ('name', 'description', 'head_name', 'contact_number', 'email', 'officer', 'sla_hours', 'is_active')
        widgets = {
            'name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'e.g. Water Supply'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 3}),
            'head_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Department head name'}),
            'contact_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': '+91 98765 43210'}),
            'email': forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'dept@smartcity.gov.in'}),
            'officer': forms.Select(attrs={'class': 'form-control'}),
            'sla_hours': forms.NumberInput(attrs={'class': 'form-control'}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['officer'].queryset = CustomUser.objects.filter(role='department')
        self.fields['officer'].required = False
        self.fields['description'].required = False
        self.fields['email'].required = False
        self.fields['contact_number'].required = False
