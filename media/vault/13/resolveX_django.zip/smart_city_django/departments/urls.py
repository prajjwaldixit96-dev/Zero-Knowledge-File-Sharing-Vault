from django.urls import path
from . import views

urlpatterns = [
    path('admin/departments/', views.admin_department_list, name='admin_departments'),
    path('admin/departments/<int:pk>/edit/', views.admin_department_edit, name='admin_department_edit'),
    path('admin/departments/<int:pk>/toggle/', views.admin_department_toggle, name='admin_department_toggle'),
]
