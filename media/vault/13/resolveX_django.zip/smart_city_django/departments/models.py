from django.db import models
from django.conf import settings


class Department(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    head_name = models.CharField(max_length=100, blank=True)
    contact_number = models.CharField(max_length=15, blank=True)
    email = models.EmailField(blank=True)
    officer = models.OneToOneField(
        settings.AUTH_USER_MODEL,
        on_delete=models.SET_NULL,
        null=True, blank=True,
        related_name='department_profile'
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    sla_hours = models.IntegerField(default=72, help_text='Default SLA in hours')

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def resolution_rate(self):
        total = self.complaints.count()
        if total == 0:
            return 0
        resolved = self.complaints.filter(status='resolved').count()
        return round((resolved / total) * 100, 1)

    def pending_count(self):
        return self.complaints.filter(status__in=['pending', 'assigned']).count()

    def in_progress_count(self):
        return self.complaints.filter(status='in_progress').count()

    def resolved_count(self):
        return self.complaints.filter(status='resolved').count()
