from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Department
from .forms import DepartmentForm


def admin_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or (request.user.role != 'admin' and not request.user.is_superuser):
            return redirect('general_login')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@admin_required
def admin_department_list(request):
    departments = Department.objects.all().order_by('name')
    form = DepartmentForm()

    if request.method == 'POST':
        form = DepartmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Department added successfully!')
            return redirect('admin_departments')
        else:
            messages.error(request, 'Please fix errors in the form.')

    return render(request, 'admin_zone/departments.html', {
        'departments': departments,
        'form': form,
    })


@login_required
@admin_required
def admin_department_edit(request, pk):
    dept = get_object_or_404(Department, pk=pk)
    form = DepartmentForm(instance=dept)

    if request.method == 'POST':
        form = DepartmentForm(request.POST, instance=dept)
        if form.is_valid():
            form.save()
            messages.success(request, f'Department "{dept.name}" updated.')
            return redirect('admin_departments')

    return render(request, 'admin_zone/department_edit.html', {
        'dept': dept,
        'form': form,
    })


@login_required
@admin_required
def admin_department_toggle(request, pk):
    dept = get_object_or_404(Department, pk=pk)
    dept.is_active = not dept.is_active
    dept.save()
    status = 'activated' if dept.is_active else 'deactivated'
    messages.success(request, f'Department "{dept.name}" has been {status}.')
    return redirect('admin_departments')
