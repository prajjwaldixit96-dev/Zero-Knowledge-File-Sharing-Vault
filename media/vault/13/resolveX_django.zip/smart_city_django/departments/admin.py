from django.contrib import admin
from .models import Department


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'head_name', 'officer', 'contact_number', 'is_active', 'sla_hours')
    list_filter = ('is_active',)
    search_fields = ('name', 'head_name', 'email')
