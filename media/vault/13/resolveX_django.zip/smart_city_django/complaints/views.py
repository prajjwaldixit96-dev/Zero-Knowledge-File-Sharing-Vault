from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from django.db.models import Q, Count
from django.http import JsonResponse
from .models import Complaint, ComplaintCategory, SubCategory, Feedback, Message, ComplaintTimeline, ComplaintPhoto
from .forms import ComplaintForm, PhotoUploadForm, FeedbackForm, MessageForm, ComplaintAssignForm, ComplaintStatusUpdateForm
from notifications.models import Notification
from departments.models import Department


def citizen_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or request.user.role != 'citizen':
            return redirect('citizen_login')
        return view_func(request, *args, **kwargs)
    return wrapper


def dept_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or request.user.role != 'department':
            return redirect('dept_login')
        return view_func(request, *args, **kwargs)
    return wrapper


def admin_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or (request.user.role != 'admin' and not request.user.is_superuser):
            return redirect('general_login')
        return view_func(request, *args, **kwargs)
    return wrapper


# ─── CITIZEN VIEWS ─────────────────────────────────────────────────────────

@login_required
@citizen_required
def citizen_dashboard(request):
    user_complaints = Complaint.objects.filter(citizen=request.user)
    stats = {
        'total': user_complaints.count(),
        'pending': user_complaints.filter(status__in=['pending', 'assigned']).count(),
        'in_progress': user_complaints.filter(status='in_progress').count(),
        'resolved': user_complaints.filter(status='resolved').count(),
    }
    recent = user_complaints[:5]
    unread_notifications = Notification.objects.filter(user=request.user, is_read=False).count()
    pending_feedback = user_complaints.filter(status='resolved').exclude(feedback__isnull=False)[:3]
    return render(request, 'citizen_zone/dashboard.html', {
        'stats': stats,
        'recent_complaints': recent,
        'unread_notifications': unread_notifications,
        'pending_feedback': pending_feedback,
    })


@login_required
@citizen_required
def file_complaint(request):
    categories = ComplaintCategory.objects.filter(is_active=True)
    form = ComplaintForm()

    if request.method == 'POST':
        form = ComplaintForm(request.POST)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.citizen = request.user
            # Pre-fill ward/block from profile
            if not complaint.ward and request.user.ward:
                complaint.ward = request.user.ward
            complaint.save()

            # Save uploaded photos (up to 5)
            photos = request.FILES.getlist('photos')
            for photo in photos[:5]:
                ComplaintPhoto.objects.create(complaint=complaint, image=photo)

            # Create timeline entry
            ComplaintTimeline.objects.create(
                complaint=complaint,
                action='Complaint Filed',
                description=f'{request.user.get_full_name()} filed a complaint via citizen portal.',
                performed_by=request.user,
                status_to='pending'
            )

            # Notify citizen
            Notification.objects.create(
                user=request.user,
                title='Complaint Submitted',
                message=f'Your complaint {complaint.complaint_number} has been submitted successfully.',
                notification_type='complaint_update',
                related_complaint=complaint,
            )

            messages.success(request, f'Complaint {complaint.complaint_number} filed successfully!')
            return redirect('citizen_track', pk=complaint.pk)

    return render(request, 'citizen_zone/file_complaint.html', {
        'form': form,
        'categories': categories,
    })


@login_required
@citizen_required
def complaint_history(request):
    complaints = Complaint.objects.filter(citizen=request.user)
    status_filter = request.GET.get('status', '')
    search = request.GET.get('search', '')

    if status_filter:
        complaints = complaints.filter(status=status_filter)
    if search:
        complaints = complaints.filter(Q(complaint_number__icontains=search) | Q(title__icontains=search) | Q(category__name__icontains=search))

    return render(request, 'citizen_zone/history.html', {
        'complaints': complaints,
        'status_filter': status_filter,
        'search': search,
    })


@login_required
@citizen_required
def track_complaint(request, pk=None):
    if pk:
        complaint = get_object_or_404(Complaint, pk=pk, citizen=request.user)
    else:
        complaint_id = request.GET.get('id', '')
        if complaint_id:
            complaint = get_object_or_404(Complaint, complaint_number=complaint_id, citizen=request.user)
        else:
            complaint = Complaint.objects.filter(citizen=request.user, status__in=['pending', 'assigned', 'in_progress']).first()

    active_complaints = Complaint.objects.filter(citizen=request.user, status__in=['pending', 'assigned', 'in_progress']).exclude(pk=complaint.pk if complaint else None)

    msg_form = MessageForm()
    if request.method == 'POST' and complaint:
        msg_form = MessageForm(request.POST)
        if msg_form.is_valid():
            msg = msg_form.save(commit=False)
            msg.complaint = complaint
            msg.sender = request.user
            msg.save()
            return redirect('citizen_track', pk=complaint.pk)

    messages_list = complaint.messages.all() if complaint else []

    return render(request, 'citizen_zone/track.html', {
        'complaint': complaint,
        'active_complaints': active_complaints,
        'messages': messages_list,
        'msg_form': msg_form,
    })


@login_required
@citizen_required
def citizen_feedback(request):
    # Resolved complaints without feedback
    pending_feedback = Complaint.objects.filter(citizen=request.user, status='resolved').exclude(feedback__isnull=False)
    submitted_feedback = Feedback.objects.filter(citizen=request.user).select_related('complaint')

    if request.method == 'POST':
        complaint_id = request.POST.get('complaint_id')
        complaint = get_object_or_404(Complaint, pk=complaint_id, citizen=request.user)
        form = FeedbackForm(request.POST)
        if form.is_valid():
            feedback = form.save(commit=False)
            feedback.complaint = complaint
            feedback.citizen = request.user
            feedback.save()
            messages.success(request, 'Feedback submitted! Thank you.')
            return redirect('citizen_feedback')

    return render(request, 'citizen_zone/feedback.html', {
        'pending_feedback': pending_feedback,
        'submitted_feedback': submitted_feedback,
        'form': FeedbackForm(),
    })


@login_required
@citizen_required
def citizen_notifications(request):
    notifs = Notification.objects.filter(user=request.user).order_by('-created_at')
    if request.GET.get('mark_all'):
        notifs.update(is_read=True)
        return redirect('citizen_notifications')
    unread = notifs.filter(is_read=False)
    unread.update(is_read=True)
    return render(request, 'citizen_zone/notifications.html', {'notifications': notifs})


# AJAX: load subcategories
def load_subcategories(request):
    category_id = request.GET.get('category_id')
    subs = SubCategory.objects.filter(category_id=category_id, is_active=True).values('id', 'name')
    return JsonResponse(list(subs), safe=False)


# ─── ADMIN VIEWS ───────────────────────────────────────────────────────────

@login_required
@admin_required
def admin_dashboard(request):
    from accounts.models import CustomUser
    total_complaints = Complaint.objects.count()
    resolved = Complaint.objects.filter(status='resolved').count()
    pending = Complaint.objects.filter(status__in=['pending', 'assigned']).count()
    departments = Department.objects.count()
    unassigned = Complaint.objects.filter(department__isnull=True, status='pending').count()
    recent = Complaint.objects.select_related('citizen', 'category').order_by('-created_at')[:10]
    return render(request, 'admin_zone/dashboard.html', {
        'total_complaints': total_complaints,
        'resolved': resolved,
        'pending': pending,
        'departments': departments,
        'unassigned': unassigned,
        'recent_complaints': recent,
        'resolution_rate': round((resolved / total_complaints * 100), 1) if total_complaints else 0,
    })


@login_required
@admin_required
def admin_complaints(request):
    complaints = Complaint.objects.select_related('citizen', 'category', 'department').order_by('-created_at')

    status_filter = request.GET.get('status', '')
    dept_filter = request.GET.get('department', '')
    search = request.GET.get('search', '')

    if status_filter:
        complaints = complaints.filter(status=status_filter)
    if dept_filter:
        complaints = complaints.filter(department_id=dept_filter)
    if search:
        complaints = complaints.filter(Q(complaint_number__icontains=search) | Q(citizen__first_name__icontains=search) | Q(category__name__icontains=search))

    departments = Department.objects.filter(is_active=True)
    return render(request, 'admin_zone/complaints.html', {
        'complaints': complaints,
        'departments': departments,
        'status_filter': status_filter,
        'dept_filter': dept_filter,
        'search': search,
    })


@login_required
@admin_required
def admin_assign(request):
    unassigned = Complaint.objects.filter(department__isnull=True, status='pending').select_related('citizen', 'category').order_by('-created_at')
    departments = Department.objects.filter(is_active=True)
    return render(request, 'admin_zone/assign.html', {
        'unassigned': unassigned,
        'departments': departments,
    })


@login_required
@admin_required
def assign_complaint(request, pk):
    if request.method == 'POST':
        complaint = get_object_or_404(Complaint, pk=pk)
        dept_id = request.POST.get('department')
        if dept_id:
            dept = get_object_or_404(Department, pk=dept_id)
            complaint.department = dept
            complaint.status = 'assigned'
            complaint.save()

            # Timeline
            ComplaintTimeline.objects.create(
                complaint=complaint,
                action='Assigned to Department',
                description=f'Complaint assigned to {dept.name} by Admin.',
                performed_by=request.user,
                status_to='assigned'
            )

            # Notify citizen
            Notification.objects.create(
                user=complaint.citizen,
                title='Complaint Assigned',
                message=f'Your complaint {complaint.complaint_number} has been assigned to {dept.name}.',
                notification_type='complaint_update',
                related_complaint=complaint,
            )

            # Notify department officer
            if dept.officer:
                Notification.objects.create(
                    user=dept.officer,
                    title='New Complaint Assigned',
                    message=f'Complaint {complaint.complaint_number} has been assigned to your department.',
                    notification_type='assignment',
                    related_complaint=complaint,
                )
            messages.success(request, f'Complaint {complaint.complaint_number} assigned to {dept.name}.')
    return redirect('admin_assign')


# ─── DEPARTMENT VIEWS ──────────────────────────────────────────────────────

@login_required
@dept_required
def dept_dashboard(request):
    dept = get_object_or_404(Department, officer=request.user)
    complaints = Complaint.objects.filter(department=dept)
    stats = {
        'assigned': complaints.count(),
        'pending': complaints.filter(status__in=['pending', 'assigned']).count(),
        'in_progress': complaints.filter(status='in_progress').count(),
        'resolved': complaints.filter(status='resolved').count(),
    }
    urgent = complaints.filter(priority__in=['high', 'urgent']).exclude(status__in=['resolved', 'closed']).order_by('created_at')[:5]
    return render(request, 'dept_zone/dashboard.html', {
        'department': dept,
        'stats': stats,
        'urgent_complaints': urgent,
    })


@login_required
@dept_required
def dept_complaints(request):
    dept = get_object_or_404(Department, officer=request.user)
    complaints = Complaint.objects.filter(department=dept).select_related('citizen', 'category').order_by('-created_at')

    status_filter = request.GET.get('status', '')
    if status_filter:
        complaints = complaints.filter(status=status_filter)

    return render(request, 'dept_zone/complaints.html', {
        'department': dept,
        'complaints': complaints,
        'status_filter': status_filter,
    })


@login_required
@dept_required
def dept_resolve(request, pk):
    dept = get_object_or_404(Department, officer=request.user)
    complaint = get_object_or_404(Complaint, pk=pk, department=dept)

    form = ComplaintStatusUpdateForm(instance=complaint)
    if request.method == 'POST':
        form = ComplaintStatusUpdateForm(request.POST, instance=complaint)
        if form.is_valid():
            old_status = complaint.status
            complaint = form.save(commit=False)
            if complaint.status == 'resolved':
                complaint.resolved_at = timezone.now()
                complaint.resolved_by = request.user
            complaint.save()

            # Upload proof photo
            if 'proof_photo' in request.FILES:
                ComplaintPhoto.objects.create(complaint=complaint, image=request.FILES['proof_photo'], caption='Resolution proof')

            # Timeline
            ComplaintTimeline.objects.create(
                complaint=complaint,
                action=f'Status Updated to {complaint.get_status_display()}',
                description=complaint.resolution_notes or f'Status changed from {old_status} to {complaint.status}',
                performed_by=request.user,
                status_to=complaint.status
            )

            # Notify citizen
            Notification.objects.create(
                user=complaint.citizen,
                title=f'Complaint {complaint.get_status_display()}',
                message=f'Your complaint {complaint.complaint_number} is now {complaint.get_status_display()}. {complaint.resolution_notes[:100] if complaint.resolution_notes else ""}',
                notification_type='status_update',
                related_complaint=complaint,
            )

            messages.success(request, f'Complaint {complaint.complaint_number} updated to {complaint.get_status_display()}.')
            return redirect('dept_complaints')

    timeline = complaint.timeline.all()
    return render(request, 'dept_zone/resolve.html', {
        'complaint': complaint,
        'form': form,
        'timeline': timeline,
        'department': dept,
    })


@login_required
@dept_required
def dept_communications(request):
    dept = get_object_or_404(Department, officer=request.user)
    # Get complaints with citizen messages
    complaints_with_msgs = Complaint.objects.filter(department=dept).prefetch_related('messages__sender')

    active_complaint_id = request.GET.get('complaint')
    active_complaint = None
    if active_complaint_id:
        active_complaint = get_object_or_404(Complaint, pk=active_complaint_id, department=dept)

    if request.method == 'POST' and active_complaint:
        msg_form = MessageForm(request.POST)
        if msg_form.is_valid():
            msg = msg_form.save(commit=False)
            msg.complaint = active_complaint
            msg.sender = request.user
            msg.save()
            # Notify citizen
            Notification.objects.create(
                user=active_complaint.citizen,
                title=f'Message from {dept.name}',
                message=msg.message[:200],
                notification_type='message',
                related_complaint=active_complaint,
            )
            return redirect(f'/complaints/dept/comms/?complaint={active_complaint.pk}')

    msg_form = MessageForm()
    messages_list = active_complaint.messages.all() if active_complaint else []

    return render(request, 'dept_zone/communications.html', {
        'department': dept,
        'complaints_with_msgs': complaints_with_msgs,
        'active_complaint': active_complaint,
        'messages': messages_list,
        'msg_form': msg_form,
    })
