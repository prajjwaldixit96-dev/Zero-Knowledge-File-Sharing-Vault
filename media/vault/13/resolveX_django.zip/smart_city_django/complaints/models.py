from django.db import models
from django.conf import settings


class ComplaintCategory(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    icon = models.CharField(max_length=100, blank=True)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = 'Complaint Categories'
        ordering = ['name']

    def __str__(self):
        return self.name


class SubCategory(models.Model):
    category = models.ForeignKey(ComplaintCategory, on_delete=models.CASCADE, related_name='subcategories')
    name = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return f"{self.category.name} → {self.name}"


class Complaint(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('assigned', 'Assigned'),
        ('in_progress', 'In Progress'),
        ('resolved', 'Resolved'),
        ('rejected', 'Rejected'),
        ('closed', 'Closed'),
    )

    PRIORITY_CHOICES = (
        ('low', 'Low'),
        ('medium', 'Medium'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    )

    # Auto-generated complaint ID like #3204
    complaint_number = models.CharField(max_length=20, unique=True, blank=True)

    citizen = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='complaints')
    category = models.ForeignKey(ComplaintCategory, on_delete=models.SET_NULL, null=True)
    sub_category = models.ForeignKey(SubCategory, on_delete=models.SET_NULL, null=True, blank=True)
    department = models.ForeignKey('departments.Department', on_delete=models.SET_NULL, null=True, blank=True, related_name='complaints')

    title = models.CharField(max_length=200)
    description = models.TextField()
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='medium')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')

    # Location
    ward = models.CharField(max_length=50)
    block = models.CharField(max_length=50, blank=True)
    address = models.CharField(max_length=255)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)

    # Resolution
    resolution_notes = models.TextField(blank=True)
    resolved_at = models.DateTimeField(null=True, blank=True)
    resolved_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True, related_name='resolved_complaints')

    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    # SLA deadline (hours)
    sla_hours = models.IntegerField(default=72)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.complaint_number} - {self.title}"

    def save(self, *args, **kwargs):
        if not self.complaint_number:
            # Generate complaint number
            last = Complaint.objects.order_by('-id').first()
            next_num = (last.id + 1) if last else 3001
            self.complaint_number = f"#{next_num}"
        super().save(*args, **kwargs)

    @property
    def status_badge_class(self):
        return {
            'pending': 'b-pending',
            'assigned': 'b-pending',
            'in_progress': 'b-progress',
            'resolved': 'b-resolved',
            'rejected': 'b-rejected',
            'closed': 'b-resolved',
        }.get(self.status, 'b-pending')

    @property
    def priority_class(self):
        return {
            'low': 'prio-l',
            'medium': 'prio-m',
            'high': 'prio-h',
            'urgent': 'prio-h',
        }.get(self.priority, 'prio-m')


class ComplaintPhoto(models.Model):
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='photos')
    image = models.ImageField(upload_to='complaint_photos/%Y/%m/')
    uploaded_at = models.DateTimeField(auto_now_add=True)
    caption = models.CharField(max_length=200, blank=True)

    def __str__(self):
        return f"Photo for {self.complaint.complaint_number}"


class ComplaintTimeline(models.Model):
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='timeline')
    action = models.CharField(max_length=100)
    description = models.TextField()
    performed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    status_to = models.CharField(max_length=20, blank=True)

    class Meta:
        ordering = ['timestamp']

    def __str__(self):
        return f"{self.complaint.complaint_number}: {self.action}"


class Feedback(models.Model):
    QUALITY_CHOICES = (
        ('fully_resolved', 'Fully Resolved'),
        ('partially_resolved', 'Partially Resolved'),
        ('not_resolved', 'Not Resolved'),
    )

    complaint = models.OneToOneField(Complaint, on_delete=models.CASCADE, related_name='feedback')
    citizen = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])
    resolution_quality = models.CharField(max_length=30, choices=QUALITY_CHOICES, default='fully_resolved')
    comments = models.TextField(blank=True)
    submitted_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Feedback for {self.complaint.complaint_number} — {self.rating}/5"


class Message(models.Model):
    """Chat messages between citizen ↔ department ↔ admin"""
    SENDER_TYPE_CHOICES = (
        ('citizen', 'Citizen'),
        ('department', 'Department'),
        ('admin', 'Admin'),
    )

    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='messages')
    sender = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    message = models.TextField()
    sent_at = models.DateTimeField(auto_now_add=True)
    is_read = models.BooleanField(default=False)

    class Meta:
        ordering = ['sent_at']

    def __str__(self):
        return f"Message on {self.complaint.complaint_number} by {self.sender}"
