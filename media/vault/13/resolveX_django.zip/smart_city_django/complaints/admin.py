from django.contrib import admin
from .models import Complaint, ComplaintCategory, SubCategory, ComplaintPhoto, ComplaintTimeline, Feedback, Message


@admin.register(ComplaintCategory)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'is_active', 'created_at')
    list_filter = ('is_active',)


@admin.register(SubCategory)
class SubCategoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'is_active')
    list_filter = ('category', 'is_active')


class PhotoInline(admin.TabularInline):
    model = ComplaintPhoto
    extra = 0


class TimelineInline(admin.TabularInline):
    model = ComplaintTimeline
    extra = 0
    readonly_fields = ('timestamp',)


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('complaint_number', 'citizen', 'category', 'department', 'priority', 'status', 'created_at')
    list_filter = ('status', 'priority', 'category', 'department')
    search_fields = ('complaint_number', 'citizen__first_name', 'citizen__last_name', 'title')
    ordering = ('-created_at',)
    inlines = [PhotoInline, TimelineInline]


@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('complaint', 'citizen', 'rating', 'resolution_quality', 'submitted_at')
    list_filter = ('rating', 'resolution_quality')
