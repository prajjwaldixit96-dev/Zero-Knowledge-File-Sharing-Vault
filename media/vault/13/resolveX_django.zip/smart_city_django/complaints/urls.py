from django.urls import path
from . import views

urlpatterns = [
    # Citizen
    path('dashboard/', views.citizen_dashboard, name='citizen_dashboard'),
    path('file/', views.file_complaint, name='file_complaint'),
    path('history/', views.complaint_history, name='citizen_history'),
    path('track/', views.track_complaint, name='citizen_track_search'),
    path('track/<int:pk>/', views.track_complaint, name='citizen_track'),
    path('feedback/', views.citizen_feedback, name='citizen_feedback'),
    path('notifications/', views.citizen_notifications, name='citizen_notifications'),
    path('ajax/subcategories/', views.load_subcategories, name='load_subcategories'),

    # Admin
    path('admin/dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin/all/', views.admin_complaints, name='admin_complaints'),
    path('admin/assign/', views.admin_assign, name='admin_assign'),
    path('admin/assign/<int:pk>/', views.assign_complaint, name='assign_complaint'),

    # Department
    path('dept/dashboard/', views.dept_dashboard, name='dept_dashboard'),
    path('dept/complaints/', views.dept_complaints, name='dept_complaints'),
    path('dept/resolve/<int:pk>/', views.dept_resolve, name='dept_resolve'),
    path('dept/comms/', views.dept_communications, name='dept_communications'),
]
