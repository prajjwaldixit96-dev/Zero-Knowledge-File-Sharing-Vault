from django import forms
from .models import Complaint, ComplaintPhoto, Feedback, Message, ComplaintCategory, SubCategory


class ComplaintForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ('category', 'sub_category', 'title', 'description', 'priority', 'ward', 'block', 'address', 'latitude', 'longitude')
        widgets = {
            'category': forms.Select(attrs={'class': 'form-input-sc', 'id': 'id_category'}),
            'sub_category': forms.Select(attrs={'class': 'form-input-sc', 'id': 'id_sub_category'}),
            'title': forms.TextInput(attrs={'class': 'form-input-sc', 'placeholder': 'Brief title of the issue'}),
            'description': forms.Textarea(attrs={'class': 'form-input-sc', 'rows': 4, 'placeholder': 'Describe the issue in detail...'}),
            'priority': forms.Select(attrs={'class': 'form-input-sc'}),
            'ward': forms.Select(choices=[('', 'Select Ward')] + [(f'Ward {i}', f'Ward {i}') for i in range(1, 21)], attrs={'class': 'form-input-sc'}),
            'block': forms.TextInput(attrs={'class': 'form-input-sc', 'placeholder': 'Block B'}),
            'address': forms.TextInput(attrs={'class': 'form-input-sc', 'placeholder': 'Full address / landmark'}),
            'latitude': forms.HiddenInput(),
            'longitude': forms.HiddenInput(),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['category'].queryset = ComplaintCategory.objects.filter(is_active=True)
        self.fields['sub_category'].queryset = SubCategory.objects.none()
        self.fields['sub_category'].required = False

        if 'category' in self.data:
            try:
                cat_id = int(self.data.get('category'))
                self.fields['sub_category'].queryset = SubCategory.objects.filter(category_id=cat_id, is_active=True)
            except (ValueError, TypeError):
                pass
        elif self.instance.pk:
            self.fields['sub_category'].queryset = self.instance.category.subcategories.filter(is_active=True)


class PhotoUploadForm(forms.ModelForm):
    class Meta:
        model = ComplaintPhoto
        fields = ('image', 'caption')
        widgets = {
            'image': forms.ClearableFileInput(attrs={'class': 'form-control', 'accept': 'image/*'}),
            'caption': forms.TextInput(attrs={'class': 'form-input-sc', 'placeholder': 'Optional caption'}),
        }


class FeedbackForm(forms.ModelForm):
    rating = forms.IntegerField(min_value=1, max_value=5, widget=forms.HiddenInput())

    class Meta:
        model = Feedback
        fields = ('rating', 'resolution_quality', 'comments')
        widgets = {
            'resolution_quality': forms.Select(attrs={'class': 'form-input-sc'}),
            'comments': forms.Textarea(attrs={'class': 'form-input-sc', 'rows': 3, 'placeholder': 'Share your experience...'}),
        }


class MessageForm(forms.ModelForm):
    class Meta:
        model = Message
        fields = ('message',)
        widgets = {
            'message': forms.TextInput(attrs={'class': 'chat-in', 'placeholder': 'Type your message...'}),
        }


class ComplaintAssignForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ('department',)
        widgets = {
            'department': forms.Select(attrs={'class': 'form-input-sc'}),
        }


class ComplaintStatusUpdateForm(forms.ModelForm):
    class Meta:
        model = Complaint
        fields = ('status', 'resolution_notes')
        widgets = {
            'status': forms.Select(attrs={'class': 'form-input-sc'}),
            'resolution_notes': forms.Textarea(attrs={'class': 'form-input-sc', 'rows': 4, 'placeholder': 'Describe work done...'}),
        }
