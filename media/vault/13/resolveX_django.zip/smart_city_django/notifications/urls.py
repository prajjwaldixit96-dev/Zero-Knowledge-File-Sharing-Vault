from django.urls import path
from . import views

urlpatterns = [
    path('admin/notifications/', views.admin_notifications, name='admin_notifications'),
]
