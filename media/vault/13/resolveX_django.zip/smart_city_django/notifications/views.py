from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Notification, Announcement
from accounts.models import CustomUser


def admin_required(view_func):
    from functools import wraps
    @wraps(view_func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_authenticated or (request.user.role != 'admin' and not request.user.is_superuser):
            return redirect('general_login')
        return view_func(request, *args, **kwargs)
    return wrapper


@login_required
@admin_required
def admin_notifications(request):
    announcements = Announcement.objects.all().order_by('-created_at')

    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        message = request.POST.get('message', '').strip()
        target = request.POST.get('target', 'all_citizens')
        priority = request.POST.get('priority', 'normal')
        ward = request.POST.get('ward', '')

        if title and message:
            announcement = Announcement.objects.create(
                title=title,
                message=message,
                target=target,
                priority=priority,
                ward=ward,
                created_by=request.user,
            )
            # Push as notifications to relevant users
            users_qs = CustomUser.objects.filter(is_active=True)
            if target == 'all_citizens':
                users_qs = users_qs.filter(role='citizen')
            elif target == 'all_departments':
                users_qs = users_qs.filter(role='department')
            elif target == 'specific_ward' and ward:
                users_qs = users_qs.filter(role='citizen', ward=ward)

            notif_list = [
                Notification(
                    user=u,
                    title=title,
                    message=message,
                    notification_type='announcement',
                )
                for u in users_qs
            ]
            Notification.objects.bulk_create(notif_list)
            messages.success(request, f'Announcement sent to {len(notif_list)} users.')
            return redirect('admin_notifications')

    return render(request, 'admin_zone/notifications.html', {
        'announcements': announcements,
    })
