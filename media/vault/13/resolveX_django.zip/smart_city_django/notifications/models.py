from django.db import models
from django.conf import settings


class Notification(models.Model):
    TYPE_CHOICES = (
        ('complaint_update', 'Complaint Update'),
        ('assignment', 'New Assignment'),
        ('status_update', 'Status Update'),
        ('message', 'New Message'),
        ('announcement', 'Announcement'),
        ('feedback_reminder', 'Feedback Reminder'),
    )

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='notifications')
    title = models.CharField(max_length=200)
    message = models.TextField()
    notification_type = models.CharField(max_length=30, choices=TYPE_CHOICES, default='complaint_update')
    related_complaint = models.ForeignKey(
        'complaints.Complaint', on_delete=models.SET_NULL, null=True, blank=True
    )
    is_read = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return f"{self.title} → {self.user.username}"


class Announcement(models.Model):
    TARGET_CHOICES = (
        ('all_citizens', 'All Citizens'),
        ('all_departments', 'All Departments'),
        ('specific_ward', 'Specific Ward'),
        ('all', 'Everyone'),
    )

    PRIORITY_CHOICES = (
        ('normal', 'Normal'),
        ('high', 'High'),
        ('urgent', 'Urgent'),
    )

    title = models.CharField(max_length=200)
    message = models.TextField()
    target = models.CharField(max_length=20, choices=TARGET_CHOICES, default='all_citizens')
    ward = models.CharField(max_length=50, blank=True, help_text='Only for Specific Ward target')
    priority = models.CharField(max_length=10, choices=PRIORITY_CHOICES, default='normal')
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
