import os
import json
from datetime import timedelta

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse, FileResponse, Http404
from django.views.decorators.http import require_POST, require_GET
from django.utils import timezone
from django.core.paginator import Paginator
from django.db.models import Q, Sum, Count

from .models import VaultFile, ShareLink, FileAccess, ActivityLog
from .forms import ShareLinkForm, FileAccessForm
from .utils import get_file_type, get_client_ip, format_file_size, get_dashboard_stats


# ──────────────────────────────────────────────────────────────────────────────
# DASHBOARD
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def dashboard(request):
    stats = get_dashboard_stats(request.user)
    return render(request, 'vault/dashboard.html', {
        'active_view': 'dash',
        **stats,
    })


# ──────────────────────────────────────────────────────────────────────────────
# FILE UPLOAD
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def upload_view(request):
    if request.method == 'POST':
        uploaded_files = request.FILES.getlist('files')
        if not uploaded_files:
            return JsonResponse({'status': 'error', 'message': 'No files provided'}, status=400)

        results = []
        for f in uploaded_files:
            mime = f.content_type or ''
            ftype = get_file_type(f.name, mime)
            size = f.size

            # Check storage quota
            profile = request.user.profile
            if profile.storage_used + size > profile.storage_quota:
                results.append({'name': f.name, 'status': 'error', 'message': 'Storage quota exceeded'})
                continue

            vault_file = VaultFile.objects.create(
                owner=request.user,
                name=f.name,
                original_name=f.name,
                file=f,
                file_type=ftype,
                size=size,
                mime_type=mime,
                is_encrypted=True,
                encryption_algo='AES-256',
            )

            # Update storage used
            profile.storage_used += size
            profile.save()

            ActivityLog.objects.create(
                user=request.user,
                action='upload',
                file=vault_file,
                description=f'Uploaded {f.name} ({format_file_size(size)}) · AES-256',
                ip_address=get_client_ip(request),
            )
            results.append({
                'name': f.name,
                'status': 'ok',
                'id': vault_file.id,
                'size': format_file_size(size),
                'type': ftype,
            })

        return JsonResponse({'status': 'ok', 'files': results})

    return render(request, 'vault/upload.html', {'active_view': 'upload'})


# ──────────────────────────────────────────────────────────────────────────────
# FILES LIST
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def files_view(request):
    qs = VaultFile.objects.filter(owner=request.user, is_deleted=False)

    # Search
    q = request.GET.get('q', '').strip()
    if q:
        qs = qs.filter(name__icontains=q)

    # Filter by type
    ftype = request.GET.get('type', '')
    if ftype and ftype != 'all':
        qs = qs.filter(file_type=ftype)

    # Sort
    sort = request.GET.get('sort', '-uploaded_at')
    sort_map = {
        'name': 'name',
        '-name': '-name',
        'size': 'size',
        '-size': '-size',
        '-uploaded_at': '-uploaded_at',
        'uploaded_at': 'uploaded_at',
    }
    qs = qs.order_by(sort_map.get(sort, '-uploaded_at'))

    paginator = Paginator(qs, 20)
    page = request.GET.get('page', 1)
    files_page = paginator.get_page(page)

    total_size = VaultFile.objects.filter(
        owner=request.user, is_deleted=False
    ).aggregate(total=Sum('size'))['total'] or 0

    return render(request, 'vault/files.html', {
        'active_view': 'files',
        'files': files_page,
        'total_files': qs.count(),
        'total_size': format_file_size(total_size),
        'search_query': q,
        'selected_type': ftype,
        'selected_sort': sort,
    })


# ──────────────────────────────────────────────────────────────────────────────
# FILE DOWNLOAD
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def file_download(request, file_id):
    vault_file = get_object_or_404(VaultFile, id=file_id, owner=request.user, is_deleted=False)
    ActivityLog.objects.create(
        user=request.user,
        action='download',
        file=vault_file,
        description=f'Downloaded {vault_file.name}',
        ip_address=get_client_ip(request),
    )
    try:
        response = FileResponse(vault_file.file.open('rb'), as_attachment=True, filename=vault_file.name)
        return response
    except FileNotFoundError:
        raise Http404("File not found on server.")


# ──────────────────────────────────────────────────────────────────────────────
# FILE DELETE
# ──────────────────────────────────────────────────────────────────────────────
@login_required
@require_POST
def file_delete(request, file_id):
    vault_file = get_object_or_404(VaultFile, id=file_id, owner=request.user, is_deleted=False)
    name = vault_file.name
    vault_file.soft_delete()
    ActivityLog.objects.create(
        user=request.user,
        action='delete',
        file=vault_file,
        description=f'Permanently deleted {name}',
        ip_address=get_client_ip(request),
    )
    return JsonResponse({'status': 'ok', 'message': f'"{name}" deleted successfully'})


# ──────────────────────────────────────────────────────────────────────────────
# FILE RENAME
# ──────────────────────────────────────────────────────────────────────────────
@login_required
@require_POST
def file_rename(request, file_id):
    vault_file = get_object_or_404(VaultFile, id=file_id, owner=request.user, is_deleted=False)
    data = json.loads(request.body)
    new_name = data.get('name', '').strip()
    if not new_name:
        return JsonResponse({'status': 'error', 'message': 'Name cannot be empty'}, status=400)
    old_name = vault_file.name
    vault_file.name = new_name
    vault_file.save()
    ActivityLog.objects.create(
        user=request.user,
        action='rename',
        file=vault_file,
        description=f'Renamed "{old_name}" → "{new_name}"',
        ip_address=get_client_ip(request),
    )
    return JsonResponse({'status': 'ok', 'name': new_name})


# ──────────────────────────────────────────────────────────────────────────────
# SHARE VIEW
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def share_view(request):
    files = VaultFile.objects.filter(owner=request.user, is_deleted=False).order_by('name')
    selected_file_id = request.GET.get('file')
    selected_file = None
    if selected_file_id:
        try:
            selected_file = files.get(id=selected_file_id)
        except VaultFile.DoesNotExist:
            pass

    share_links = ShareLink.objects.filter(
        created_by=request.user
    ).select_related('file').order_by('-created_at')

    return render(request, 'vault/share.html', {
        'active_view': 'share',
        'files': files,
        'selected_file': selected_file,
        'share_links': share_links,
    })


@login_required
@require_POST
def generate_share_link(request):
    data = json.loads(request.body)
    file_id = data.get('file_id')
    expiry = data.get('expiry', '')
    password = data.get('password', '')
    max_downloads = int(data.get('max_downloads', 0))
    allow_preview = data.get('allow_preview', True)

    vault_file = get_object_or_404(VaultFile, id=file_id, owner=request.user, is_deleted=False)

    expires_at = None
    if expiry:
        delta_map = {'1h': timedelta(hours=1), '24h': timedelta(hours=24),
                     '7d': timedelta(days=7), '30d': timedelta(days=30)}
        if expiry in delta_map:
            expires_at = timezone.now() + delta_map[expiry]

    link = ShareLink(
        file=vault_file,
        token=ShareLink.generate_token(),
        created_by=request.user,
        expires_at=expires_at,
        max_downloads=max_downloads,
        allow_preview=allow_preview,
    )
    link.set_password(password)
    link.save()

    ActivityLog.objects.create(
        user=request.user,
        action='link_generate',
        file=vault_file,
        description=f'Generated secure share link for {vault_file.name}',
        ip_address=get_client_ip(request),
    )

    return JsonResponse({
        'status': 'ok',
        'token': link.token,
        'url': request.build_absolute_uri(link.public_url()),
        'expires_at': link.expires_at.isoformat() if link.expires_at else None,
        'has_password': link.has_password(),
        'id': link.id,
    })


@login_required
@require_POST
def revoke_share_link(request, link_id):
    link = get_object_or_404(ShareLink, id=link_id, created_by=request.user)
    link.is_active = False
    link.save()
    ActivityLog.objects.create(
        user=request.user,
        action='link_revoke',
        file=link.file,
        description=f'Revoked share link for {link.file.name}',
        ip_address=get_client_ip(request),
    )
    return JsonResponse({'status': 'ok'})


# ──────────────────────────────────────────────────────────────────────────────
# PUBLIC SHARE ACCESS
# ──────────────────────────────────────────────────────────────────────────────
def public_share_view(request, token):
    link = get_object_or_404(ShareLink, token=token, is_active=True)
    error = None
    password_required = link.has_password()
    authenticated = False

    if not link.is_valid():
        return render(request, 'public/share_expired.html', {'link': link})

    if password_required:
        if request.method == 'POST':
            pw = request.POST.get('password', '')
            if link.check_password(pw):
                authenticated = True
                request.session[f'share_{token}_auth'] = True
            else:
                error = 'Incorrect password.'
        elif request.session.get(f'share_{token}_auth'):
            authenticated = True
    else:
        authenticated = True

    if authenticated and request.method == 'POST' and 'download' in request.POST:
        link.download_count += 1
        link.save()
        try:
            response = FileResponse(
                link.file.file.open('rb'),
                as_attachment=True,
                filename=link.file.name
            )
            ActivityLog.objects.create(
                user=link.created_by,
                action='link_access',
                file=link.file,
                description=f'Public download via share link · {get_client_ip(request)}',
                ip_address=get_client_ip(request),
            )
            return response
        except FileNotFoundError:
            error = 'File not found on server.'

    return render(request, 'public/share_view.html', {
        'link': link,
        'password_required': password_required,
        'authenticated': authenticated,
        'error': error,
    })


# ──────────────────────────────────────────────────────────────────────────────
# ACCESS CONTROL
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def access_view(request):
    files = VaultFile.objects.filter(owner=request.user, is_deleted=False).order_by('name')
    access_rules = FileAccess.objects.filter(
        file__owner=request.user
    ).select_related('file', 'shared_with').order_by('-granted_at')

    selected_file_id = request.GET.get('file')
    selected_file = None
    file_rules = []
    if selected_file_id:
        try:
            selected_file = files.get(id=selected_file_id)
            file_rules = FileAccess.objects.filter(file=selected_file).order_by('-granted_at')
        except VaultFile.DoesNotExist:
            pass

    form = FileAccessForm()

    return render(request, 'vault/access.html', {
        'active_view': 'access',
        'files': files,
        'access_rules': access_rules,
        'selected_file': selected_file,
        'file_rules': file_rules,
        'form': form,
    })


@login_required
@require_POST
def grant_access(request):
    data = json.loads(request.body)
    file_id = data.get('file_id')
    email = data.get('email', '').strip().lower()
    permission = data.get('permission', 'view')
    expires_at_str = data.get('expires_at', '')

    if not email:
        return JsonResponse({'status': 'error', 'message': 'Email is required'}, status=400)

    vault_file = get_object_or_404(VaultFile, id=file_id, owner=request.user, is_deleted=False)

    expires_at = None
    if expires_at_str:
        from django.utils.dateparse import parse_datetime
        expires_at = parse_datetime(expires_at_str)

    # Check if access rule already exists
    rule, created = FileAccess.objects.get_or_create(
        file=vault_file,
        shared_with_email=email,
        defaults={
            'permission': permission,
            'granted_by': request.user,
            'expires_at': expires_at,
            'status': 'active',
        }
    )
    if not created:
        rule.permission = permission
        rule.status = 'active'
        rule.expires_at = expires_at
        rule.save()

    # Link to user if they exist
    try:
        shared_user = User.objects.get(email=email)
        rule.shared_with = shared_user
        rule.save()
    except User.DoesNotExist:
        pass

    ActivityLog.objects.create(
        user=request.user,
        action='access_grant',
        file=vault_file,
        description=f'Granted {permission} access to {email} for {vault_file.name}',
        ip_address=get_client_ip(request),
    )

    return JsonResponse({
        'status': 'ok',
        'id': rule.id,
        'email': email,
        'permission': permission,
        'message': f'Access granted to {email}'
    })


@login_required
@require_POST
def revoke_access(request, rule_id):
    rule = get_object_or_404(FileAccess, id=rule_id, file__owner=request.user)
    email = rule.shared_with_email
    fname = rule.file.name
    rule.status = 'revoked'
    rule.save()
    ActivityLog.objects.create(
        user=request.user,
        action='access_revoke',
        file=rule.file,
        description=f'Revoked access for {email} on {fname}',
        ip_address=get_client_ip(request),
    )
    return JsonResponse({'status': 'ok', 'message': f'Access revoked for {email}'})


# ──────────────────────────────────────────────────────────────────────────────
# ACTIVITY LOGS
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def logs_view(request):
    qs = ActivityLog.objects.filter(user=request.user).select_related('file')

    action_filter = request.GET.get('action', '')
    if action_filter:
        qs = qs.filter(action=action_filter)

    q = request.GET.get('q', '').strip()
    if q:
        qs = qs.filter(Q(description__icontains=q) | Q(file__name__icontains=q))

    paginator = Paginator(qs, 25)
    page = paginator.get_page(request.GET.get('page', 1))

    return render(request, 'vault/logs.html', {
        'active_view': 'logs',
        'logs': page,
        'action_choices': ActivityLog.ACTION_CHOICES,
        'action_filter': action_filter,
        'search_query': q,
    })


# ──────────────────────────────────────────────────────────────────────────────
# SETTINGS
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def settings_view(request):
    from accounts.forms import ProfileUpdateForm, ChangePasswordForm
    profile_form = ProfileUpdateForm(instance=request.user)
    password_form = ChangePasswordForm(request.user)
    return render(request, 'vault/settings.html', {
        'active_view': 'settings',
        'profile_form': profile_form,
        'password_form': password_form,
    })


# ──────────────────────────────────────────────────────────────────────────────
# ADMIN PANEL
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def admin_panel_view(request):
    if not (request.user.is_staff or request.user.profile.is_admin):
        messages.error(request, 'Access denied. Admin only.')
        return redirect('dashboard')

    users = User.objects.select_related('profile').order_by('-date_joined')
    q = request.GET.get('q', '').strip()
    if q:
        users = users.filter(
            Q(email__icontains=q) | Q(first_name__icontains=q) | Q(last_name__icontains=q)
        )

    paginator = Paginator(users, 20)
    users_page = paginator.get_page(request.GET.get('page', 1))

    # Platform stats
    total_users = User.objects.count()
    total_files = VaultFile.objects.filter(is_deleted=False).count()
    total_storage = sum(
        u.profile.storage_used for u in User.objects.select_related('profile').all()
    )
    total_links = ShareLink.objects.filter(is_active=True).count()

    return render(request, 'vault/admin_panel.html', {
        'active_view': 'admin',
        'users': users_page,
        'search_query': q,
        'total_users': total_users,
        'total_files': total_files,
        'total_storage': format_file_size(total_storage),
        'total_links': total_links,
    })


@login_required
@require_POST
def admin_toggle_user(request, user_id):
    if not (request.user.is_staff or request.user.profile.is_admin):
        return JsonResponse({'status': 'error', 'message': 'Forbidden'}, status=403)
    target = get_object_or_404(User, id=user_id)
    if target == request.user:
        return JsonResponse({'status': 'error', 'message': 'Cannot suspend yourself'}, status=400)
    profile = target.profile
    profile.is_suspended = not profile.is_suspended
    profile.save()
    return JsonResponse({
        'status': 'ok',
        'suspended': profile.is_suspended,
        'message': f'User {"suspended" if profile.is_suspended else "reactivated"}'
    })


@login_required
@require_POST
def admin_delete_user(request, user_id):
    if not (request.user.is_staff or request.user.profile.is_admin):
        return JsonResponse({'status': 'error', 'message': 'Forbidden'}, status=403)
    target = get_object_or_404(User, id=user_id)
    if target == request.user:
        return JsonResponse({'status': 'error', 'message': 'Cannot delete yourself'}, status=400)
    email = target.email
    target.delete()
    return JsonResponse({'status': 'ok', 'message': f'User {email} deleted'})


# ──────────────────────────────────────────────────────────────────────────────
# API: FILES LIST (JSON)
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def api_files_list(request):
    files = VaultFile.objects.filter(owner=request.user, is_deleted=False).order_by('-uploaded_at')
    data = [{
        'id': f.id,
        'name': f.name,
        'size': f.size_display(),
        'type': f.file_type,
        'icon': f.type_icon_class(),
        'uploaded_at': f.uploaded_at.isoformat(),
        'encryption_algo': f.encryption_algo,
    } for f in files]
    return JsonResponse({'files': data})


# ──────────────────────────────────────────────────────────────────────────────
# API: STORAGE INFO
# ──────────────────────────────────────────────────────────────────────────────
@login_required
def api_storage_info(request):
    profile = request.user.profile
    return JsonResponse({
        'used': profile.storage_used,
        'used_display': format_file_size(profile.storage_used),
        'quota': profile.storage_quota,
        'quota_display': format_file_size(profile.storage_quota),
        'percent': profile.storage_percent(),
    })
